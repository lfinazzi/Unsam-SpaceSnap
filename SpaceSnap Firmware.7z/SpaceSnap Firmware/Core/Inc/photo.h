/*
 * photo.h - photo buffer definition and image handling functions
 *
 *  Created on: Nov 27, 2025
 *      Author: finazzi
 */

#ifndef __PHOTO_H__
#define __PHOTO_H__

#include <stdint.h>
#include "dcmi.h"

#define H 									(640U)								// Horizontal resolution
#define L 									(480U)								// Vertical resolution

// Camera
#define CAM_A_I2C_ADDR	 					0x90								// i2C address for Camera A (write)
#define CAM_B_I2C_ADDR 						0xBA								// i2C address for Camera B (write)
#define PARAM_POOL_ADDR						0xFC00								// parameter pool base (16b register address)
#define COMMAND_REG_ADDR					0x0040								// command register address (16b)
#define SYS_STATE_CHANGE_CFG				0x2800								// parameter value used to request Change-Config (start stream)
#define HC_SYSMGR_SET_STATE					0x8100								// Command value to request new state
#define I2C_TIMEOUT_MS						(200U)
#define DOORBELL_POLL_MS					(5U)
#define DOORBELL_TIMEOUT_MS					(5000U)

// SRAM memory
#define RAW_PHOTO_BASE_ADDRESS 				(0x60000000U)						// NOR SRAM BANK 1
#define RAW_PHOTO_BYTE_SIZE 				(2*H*L)								// in bytes
#define NUM_TRANSFERS						(RAW_PHOTO_BYTE_SIZE / 4U)
#define NUM_BUFFERS 						(3U)
#define COMPRESSED_PHOTO_BASE_ADDRESS		(RAW_PHOTO_BASE_ADDRESS) + (NUM_BUFFERS*RAW_PHOTO_BYTE_SIZE) 			// 16b data

extern volatile uint8_t frame_done;

typedef struct {
	uint16_t data[L*H];               // Image data in YCbCr 4:2:2 format
	uint8_t  cam_number;			  // Number of camera with which picture was taken
	uint32_t photo_timestamp;		  // photo timestamp
	uint8_t  compression; 			  // compression quality (0 raw, 1 good, 2 standard, 3 poor)
	uint8_t  index; 				  // index in volatile memory
} raw_photo_t;

typedef struct {
	raw_photo_t raw_buffer[3];
} raw_photo_buffer_t;

typedef struct {
	uint16_t *data;	                  // Image data in YCbCr 4:2:2 format
	uint8_t  cam_number;			  // Number of camera with which picture was taken
	uint32_t photo_timestamp;		  // photo timestamp
	uint8_t  compression; 			  // compression quality (0 raw, 1 good, 2 standard, 3 poor)
} compressed_photo_t;

typedef struct {
	compressed_photo_t *photos;
	uint8_t current_index;
} compressed_photo_buffer_t;


/**********************************************************
 * Function to initialize parameters for both cameras
 * in Unsam SpaceSnap
 **********************************************************/
void Camera_Init(void);

/**********************************************************
 * Function to enable camera A and disable camera B
 **********************************************************/
void ActivateCameraA(void);

/**********************************************************
 * Function to enable camera B and disable camera A
 **********************************************************/
void ActivateCameraB(void);

/**********************************************************
 * Auxilliary function to write 16b value to 16b reg
 * through i2C
 **********************************************************/
HAL_StatusTypeDef cam_write_reg16_uint16(uint8_t camera, uint16_t reg16, uint16_t val16);

/**********************************************************
 * Auxilliary function to red from 16b reg to 16b buffer
 * through i2C
 **********************************************************/
HAL_StatusTypeDef cam_read_reg16_uint16(uint8_t camera, uint16_t reg16, uint16_t *out16);

/**********************************************************
 * Callback function for DMA transfer of raw image
 **********************************************************/
void HAL_DCMI_XferCpltCallback(DMA_HandleTypeDef *hdma);

/**********************************************************
 * Arms DCMI capture of a single frame before requesting
 * it to the sensor through i2C and saves that frame into
 * the corresponding buffer number and the corresponding
 * frame index in that buffer
 **********************************************************/
HAL_StatusTypeDef ArmDCMICapture(uint8_t camera_number, uint8_t buffer_number);



#endif /* __PHOTO_H__ */



