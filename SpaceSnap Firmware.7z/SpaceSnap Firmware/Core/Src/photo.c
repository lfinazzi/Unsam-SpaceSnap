/*
 * photo.c - photo buffer definition and image handling functions
 *
 *  Created on: Nov 27, 2025
 *      Author: finazzi
 */

#include "photo.h"
#include "dcmi.h"
#include "fsmc.h"
#include "i2c.h"

volatile uint8_t frame_done = 0;

void Camera_Init(void)
{
	// camera addresses:
	// A: 0x90
	// B: 0xBA
	// transfers done 8b at a time, MSB FIRST
}

void ActivateCameraA(void)
{

}

void ActivateCameraB(void)
{

}

HAL_StatusTypeDef cam_write_reg16_uint16(uint8_t camera, uint16_t reg16, uint16_t val16)
{
	uint8_t buf[4];
	buf[0] = (uint8_t)( (reg16 >> 8) & 0xFF );	// reg  MSB
	buf[1] = (uint8_t)( (reg16     ) & 0xFF );	// reg  LSB
	buf[2] = (uint8_t)( (val16 >> 8) & 0xFF );	// data MSB
	buf[3] = (uint8_t)( (reg16     ) & 0xFF );	// data LSB

	if (camera == 0)		// Camera A
		return HAL_I2C_Master_Transmit(&hi2c2, (uint16_t)CAM_A_I2C_ADDR, buf, sizeof(buf), I2C_TIMEOUT_MS);
	else if (camera == 1)	// Camera B
		return HAL_I2C_Master_Transmit(&hi2c2, (uint16_t)CAM_B_I2C_ADDR, buf, sizeof(buf), I2C_TIMEOUT_MS);
	else
		return HAL_ERROR;		// TODO - handle this!
}

HAL_StatusTypeDef cam_read_reg16_uint16(uint8_t camera, uint16_t reg16, uint16_t *out16)
{
	uint8_t reg_buf[2];
	reg_buf[0] = (uint8_t)( (reg16 >> 8) & 0xFF );
	reg_buf[1] = (uint8_t)( (reg16     ) & 0xFF );

	HAL_StatusTypeDef st;

	// sends the 16b register address (no stop) and then performs a 16b read
	if (camera == 0)		// Camera A
		st = HAL_I2C_Master_Transmit(&hi2c2, (uint16_t)CAM_A_I2C_ADDR, reg_buf, 2, I2C_TIMEOUT_MS);
	else if (camera == 1)	// Camera B
		st = HAL_I2C_Master_Transmit(&hi2c2, (uint16_t)CAM_B_I2C_ADDR, reg_buf, 2, I2C_TIMEOUT_MS);
	else
		return HAL_ERROR;		// TODO - handle this!

	if(!HAL_OK) return st;

	uint8_t val_buf[2];
	if (camera == 0)		// Camera A
		st = HAL_I2C_Master_Receive(&hi2c2, (uint16_t)CAM_A_I2C_ADDR, val_buf, 2, I2C_TIMEOUT_MS);
	else if (camera == 1)	// Camera B
		st = HAL_I2C_Master_Transmit(&hi2c2, (uint16_t)CAM_B_I2C_ADDR, val_buf, 2, I2C_TIMEOUT_MS);
	else
		return HAL_ERROR;		// TODO - handle this!

	if(!HAL_OK) return st;

	*out16 = (uint16_t)( val_buf[0] << 8 | val_buf[1] );
	return HAL_OK;
}

void HAL_DCMI_XferCpltCallback(DMA_HandleTypeDef *hdma)
{
	// DMA finished exact expected transfer
	frame_done = 1;
}

HAL_StatusTypeDef ArmDCMICapture(uint8_t camera_number, uint8_t buffer_number)
{
	frame_done = 0;

	// i2C command part is still pending!

	//signal camera through i2C to start transfer
	HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_CONTINUOUS,
			(uint32_t)(RAW_PHOTO_BASE_ADDRESS + buffer_number*RAW_PHOTO_BYTE_SIZE), NUM_TRANSFERS); 	// Every capture is 32b (2 pixels)

	while(!frame_done) {
		// TODO - timeout?
	}

	HAL_DCMI_Stop(&hdcmi);
	HAL_DMA_Abort(hdcmi.DMA_Handle);

	return HAL_OK;

}
